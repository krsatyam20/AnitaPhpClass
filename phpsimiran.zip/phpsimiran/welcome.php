<?php 
include("phpcode/welcomeCode.php");
?>
<html>
<head>


</head>
<body>

<table>
<tr>
<th>Student Id</th>
<th>Student name</th>
<th>Student Email</th>

</tr>
<?php 
$sn=1;
 while($row=mysqli_fetch_array($query)) { 
$imgName=!empty($row['uimg']) ? $row['uimg'] : "";
//print_r($row);
?>
<tr>
<td><?php echo  $sn; ?><td>
<td><?php echo $row['uname']; ?><td>
<td><?php echo $row['uemail']; ?><td>
<?php if(!empty($imgName)) { ?>
<td><img src="image/<?php echo $imgName; ?> " style="width:150px;height:150px;"><td>
<?php } ?>
</tr>
<?php $sn++ ;} ?>


</table>


</body>
</html>