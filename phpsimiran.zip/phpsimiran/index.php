<?php
include("phpcode/indexCode.php");
?>

<html>
<head>
</head>
<body>
<h1><?php echo $msg; ?></h1>
<form method="POST" enctype="multipart/form-data" >
<p><input type="text" name="uname" /> </p>
<p><input type="text" name="uemail" /> </p>
<p><input type="file" name="uimg" /> </p>

<p><input type="submit" name="submit" /> </p>
</form>






</body>
</html>