<?php

$msg="My First Home Page";
include('phpcode/dbConnection.php');


if(isset($_POST['submit'])) {
	
$name=!empty($_POST['uname']) ? $_POST['uname'] : " ";
$email=!empty($_POST['uemail']) ? $_POST['uemail'] : " " ;	

$source=$_FILES['uimg']['tmp_name'];
$imgName=time().$_FILES['uimg']['name'];
$target='image/'.$imgName;
   
$sql="insert into userdetails(uname,uemail,uimg) values ('".$name."','".$email."','".$imgName."')";

if($conn->query($sql) === true){
copy($source,$target);
	
$msg="data succesfuly inserted";
header("Location: welcome.php"); 


}else{
	$msg="Data not succesfuly insert";
}
	
}

     
?>