<?php

include('dbConnection.php');

$sql="select * from userdetails";

$query=$conn->query($sql);


?>
